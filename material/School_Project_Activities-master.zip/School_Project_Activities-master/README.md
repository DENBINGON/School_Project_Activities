# School_Project_Activities
School project for admission to the exam
